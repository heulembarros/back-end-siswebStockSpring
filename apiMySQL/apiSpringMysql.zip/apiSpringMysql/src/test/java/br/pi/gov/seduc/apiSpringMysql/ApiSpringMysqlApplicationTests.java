package br.pi.gov.seduc.apiSpringMysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiSpringMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
