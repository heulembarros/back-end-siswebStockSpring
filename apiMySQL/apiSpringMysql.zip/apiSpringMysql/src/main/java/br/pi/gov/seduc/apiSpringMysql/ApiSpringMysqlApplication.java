package br.pi.gov.seduc.apiSpringMysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiSpringMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiSpringMysqlApplication.class, args);
	}

}
